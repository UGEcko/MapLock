import * as remapper from "https://deno.land/x/remapper@2.1.0/src/mod.ts"


export function rainbowNotes(time: number, dur: number) {
    remapper.notesBetween(time, dur, (note) => {
        note.animate.color = [1, 0, 0, 0.1], [1, 0.5, 0, 0.2], [0, 0.5, 0.5, 0.3], []
    })
}

